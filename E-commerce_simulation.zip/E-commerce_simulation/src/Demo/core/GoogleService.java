package Demo.core;


public interface GoogleService {
	void LoginwGoogle(String user);
}
