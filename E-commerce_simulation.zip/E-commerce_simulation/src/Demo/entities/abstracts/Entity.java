package Demo.entities.abstracts;

public interface Entity {

}
