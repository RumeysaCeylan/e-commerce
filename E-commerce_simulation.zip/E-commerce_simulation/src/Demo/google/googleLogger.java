package Demo.google;

public class googleLogger {
	public void login(String mail) {
		System.out.println("Google adresi ile giri� yap�l�yor : "+mail);
	}
}
